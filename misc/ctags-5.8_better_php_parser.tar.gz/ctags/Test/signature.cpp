/* Tests for collection of signature */

void foo (int a, char b) {}

int bar (a, b) int a; char b; {}

char *BAR::bar (char *c, double d[]) const {}

void foobar __ARGS ((int a, char b));
