// csharp_volatile.cs
class Test
{
   public volatile int i;
   
   Test(int _i)
   {
      i = _i;
   }
   public static void Main()
   {
      
   }
}
