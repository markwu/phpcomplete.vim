(* the string "(*" does NOT start a comment *)
let p = print_endline
let _ = p "foo"
