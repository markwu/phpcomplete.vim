=head1 NAME
Some stuff to ignore
package NotAPackage;
sub NotASub {}
=cut
package A::B;
sub MySub {}
use constant A => 3;
LABEL:
__END__
sub IgnoreSub {}
