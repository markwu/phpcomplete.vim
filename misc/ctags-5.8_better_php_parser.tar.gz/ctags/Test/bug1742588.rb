class A
 def a()
  super(" do ")
 end
 def b()
 end
end
