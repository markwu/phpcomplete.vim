MY_MACRO(qwerty < 1);

class Abra : public Kadabra
{
};
