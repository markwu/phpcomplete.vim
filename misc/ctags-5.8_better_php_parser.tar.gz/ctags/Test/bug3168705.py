class A:
    def func1():
        """this is
a comment"""
        pass

    def func2():
        pass

