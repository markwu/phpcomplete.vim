def testFunc():
    print 'The following works now' + '"""'

def main():
    print 'nothing'
    print 'This is another quoted triple string: """.'
    return 0
