extern int a;
extern struct B b;
struct S;
class C;
