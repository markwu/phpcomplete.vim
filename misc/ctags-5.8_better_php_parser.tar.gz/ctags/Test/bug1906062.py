include_file = '''
class (b)
'''

